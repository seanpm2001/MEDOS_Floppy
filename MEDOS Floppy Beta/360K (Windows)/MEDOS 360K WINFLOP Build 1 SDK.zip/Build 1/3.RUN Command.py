compat4 = str
print ("Command testing")
print ("Test the Windows 3.x compatibility command")
print ("Type '3.RUN' to try out the command!")
print ("Warning! Commands are CaSe SeNsItIvE")
compat4 = str(input("FC:\\"))
if compat4 == ("3.RUN"):
	print ("Windows 3 compatibility center")
	print ("F Windows 3.0")
	print ("G Windows 3.1")
	print ("H Windows 3.11")
	print ("I Windows 3.2")
	print ("Choose a letter F-I then click enter to continue compatibility testing")
	print ("Type XE to quit")
testconfirm = int(input("Did the command info look right? type 1 to confirm, type anything else and/or press enter to quit "))
if testconfirm == 1:
    print ("Done!")
else:
    print ("Done!")
   